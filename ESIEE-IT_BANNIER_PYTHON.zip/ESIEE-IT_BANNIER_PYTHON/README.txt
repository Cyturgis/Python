############### PROJET 1 ############### 

Lancer main.py
Contient un quiz de 10 questions sur les capitales du monde. 

############### FIN PROJET 1 ############### 



############### PROJET 2 ############### 

Lancer main.py
Contient deux outils. 
Option 0 : Générateur de mot de passe avec un test de force (entropie).
Option 1 : Générateur de passphrase utilisant une wordlist.
L'option q permet de quitter le programme.

############### FIN PROJET 2 ###############
