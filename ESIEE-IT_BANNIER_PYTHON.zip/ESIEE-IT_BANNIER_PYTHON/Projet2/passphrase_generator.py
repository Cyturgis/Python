import random

#classe qui contient la structure pour générer la passphrase ainsi que la fonction pour la créer
class PassphraseGenerator:

    #structure pour préparer la génération de la passphrase
    #ici, le code ouvre en mode lecture la wordlist eff_large_wordlist pour y prendre des mots
    def __init__(self, word_list_file="eff_large_wordlist.txt"):
        with open(word_list_file, 'r') as f:
            #on ajoute à la variable wordlist le deuxième mot de la ligne choisi en supprimant les espaces
            self.word_list = [line.strip().split()[1] for line in f]

    #fonction qui permet de choisir aléatoirement des mots dans la wordlist pour les ajouter à la variable word_list
    def generate_passphrase(self, num_words=5):
        return ' '.join(random.choices(self.word_list, k=num_words))
