from password_generator import PasswordGenerator
from password_tester import PasswordTester
from passphrase_generator import PassphraseGenerator

if __name__ == "__main__":

    #initialisation de la variable choix qui va contenir le choix de l'utilisateur 
    choix = ""


#boucle while qui fait tourner le programme tant que q (quit) n'est pas entré au clavier

while choix != 'q':
    #l'utilisateur à le choix d'utiliser 2 outils ou de quitter le programme
    print("###########################################")
    print("0 - Générateur de mot de passe")
    print("1 - Générateur de passphrase")
    print("q - Quitter")
    print("###########################################")

    #l'utilisateur fait son choix d'outil
    choix = input("Choix de l'outil : ")
    print("###########################################")

    #si 0 est choisi, il exécute le générateur de mot de passe
    if choix == "0":
        #le user doit entrer 4 paramètres : le nombre de minuscules, de majuscules, de digits et de caractères spéciaux
        lowerCases = int(input('Nombre de minuscules : '))
        upperCases = int(input('Nombre de majuscules : '))
        nbDigits = int(input('Nombre de chiffres : '))
        nbSpecials = int(input('Nombre de caractères spéciaux : '))

        #une variable generator avec les 4 paramètres demandés précédemment est créée
        generator = PasswordGenerator(lower=lowerCases, upper=upperCases, digits=nbDigits, specials=nbSpecials)

        #la variable est alors utilisée avec la fonction generate_password qui s'occupe de choisir aléatoirement les caractères que l'on veut et de les mélanger
        password = generator.generate_password()

        #affichage du mot de passe
        print(f"Mot de passe généré : {password}")
               
        #le programme teste ensuite la force du mot de passe grâce aux fonctions calculate_entropy et test_password_strenght
        tester = PasswordTester()
        entropy = tester.calculate_entropy(password)
        strength = tester.test_password_strength(password)

        #affichage de l'entropie ainsi que de la force
        print(f"Entropie : {entropy:.2f} bits - Force : {strength}")
    
    #si 1 est choisi, le programme exécute le générateur de passphrase
    elif choix == "1":
        #le programme demande le nombre de mot que le user veut dans la passphrase et la génère
        nbWord = int(input("Nombre de mots de la passphrase : "))
        passphrase_gen = PassphraseGenerator()
        passphrase = passphrase_gen.generate_passphrase(num_words=nbWord)

        #affichage de la passphrase
        print(f"Passphrase générée : {passphrase}")
    
    #si q est choisi, le programme se coupe
    elif choix == 'q':
        print("Arrêt du programme")
    
    else:
        print("Choix invalide")

