import random
import string


#class qui contient la structure pour générer le mot de passe ainsi qu'une fonction permettant de choisir de manière aléatoire les caractères
class PasswordGenerator:
    def __init__(self, lower=0, upper=0, digits=0, specials=0):
        self.lower = lower
        self.upper = upper
        self.digits = digits
        self.specials = specials
        self.special_chars = "!@#$%^&*()-_=+[]{}|;:',.<>?/"

    #la fonction choisi aléatoirement les minuscules, les majuscules, les chiffres et les caractères spéciaux en fonction du nombre de caractères que le user a entré
    #elle va les stocker ensuite dans la variable "password"
    def generate_password(self):
        password = (
            random.choices(string.ascii_lowercase, k=self.lower) +
            random.choices(string.ascii_uppercase, k=self.upper) +
            random.choices(string.digits, k=self.digits) +
            random.choices(self.special_chars, k=self.specials)
        )

        #le programme mélange les caractères pour rendre le mot de passe "complexe" et sans structure du genre qavcAAEJ3265_,+) (tout à la suite)
        random.shuffle(password)
        return ''.join(password)
