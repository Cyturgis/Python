import math

#la classe contient deux fonctions permettant de calculer l'entropie et la force du mot de passe
class PasswordTester:
    @staticmethod

    #fonction calculant l'entropie
    def calculate_entropy(password):
        alphabet_size = 0

        #premier if qui vérifie si il y a une minuscule, si une minuscule est trouvé le compteur alphabet_size prend +26 (taille d'alphabet)
        if any(c.islower() for c in password):
            alphabet_size += 26
        #deuxième if qui vérifie si il y a une majuscule, si une majuscule est trouvé le compteur alphabet_size prend +26 (taille d'alphabet)
        if any(c.isupper() for c in password):
            alphabet_size += 26
        #troisième if qui vérifie si il y a un digit, si un digits est trouvé le compteur alphabet_size prend +10 (nombre de chiffre 0-9)
        if any(c.isdigit() for c in password):
            alphabet_size += 10
        #quatrième if qui vérifie si il y a un caractère, si un caractère est trouvé le compteur alphabet_size prend +32 (nombre de caractères en tout)
        if any(c in "!@#$%^&*()-_=+[]{}|;:',.<>?/" for c in password):
            alphabet_size += 32

        #une fois que la taille d'alphabet est determinée, la ligne ci-dessous calcule l'entropie du mot de passe grâce à la formule tailleMDP * log2(tailleAlphabet)
        #exemple : pour des paramètres en 4, 4, 4, 4, il y a au moins une minuscule, une majuscule, un digit et un caractère
        #donc la taille d'alphabet est : 26 + 26 + 10 + 32 = 96 et la taille du mdp de 16 caractères
        #entropie = 16×log2(96) = 104.87
        entropy = len(password) * math.log2(alphabet_size)
        return entropy

    #la fonction vérifie si la taille du mot de passe est inférieur à 50 (faible), entre 50 et 80 (moyen) ou supérieur à 80 (fort)
    @staticmethod
    def test_password_strength(password):
        entropy = PasswordTester.calculate_entropy(password)
        if entropy < 50:
            return "Faible"
        elif entropy < 80:
            return "Moyenne"
        else:
            return "Forte"
