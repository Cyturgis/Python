import random
from questions import Question

# Classe QCM
class QCM:

    def __init__(self):
        self.questions = []
        self.score = 0

    def addQuestion(self, question):
        self.questions.append(question)

    def askQuestion(self):
        random.shuffle(self.questions)

        for i, question in enumerate(self.questions):
            print("")
            print(f"Question n°{i + 1}: {question.texte}")

            #shuffle des réponses pour pas qu'elles n'apparaissent dans le même ordre
            shuffled_choices = list(enumerate(question.choix))
            random.shuffle(shuffled_choices)

            #création d'un mapping pour relier les choix mélangés à leur lettre
            choice_mapping = {chr(97 + idx): original_idx for idx, (original_idx, _) in enumerate(shuffled_choices)}

            #afficher les réponses mélangées
            for idx, (original_idx, choix) in enumerate(shuffled_choices):
                print(f"{chr(97 + idx)}) {choix}")

            #demander la réponse de l'utilisateur
            reponse = input("Choisissez une réponse (a, b ou c) : ").strip().lower()

            #convertir la lettre choisie en index original
            if reponse in choice_mapping:
                original_choice_idx = choice_mapping[reponse]
                original_letter = chr(97 + original_choice_idx)  # Convertir l'index original en lettre

                #vérifier si la réponse est correcte
                if question.verifier_reponse(original_letter):
                    print("Bonne réponse\n")
                    self.score += 1
                #sinon on affiche que la réponse est mauvaise
                else:
                    print(f"Mauvaise réponse. Correction : {question.reponse}) {question.choix[ord(question.reponse) - 97]}\n")
            else:
                print("Réponse invalide. Aucun point accordé.\n")

            print("##################################################################")

    #affichage du score sous la forme (score/taille-questions)
    def printScore(self):
        print(f"\nScore final : {self.score}/{len(self.questions)}")