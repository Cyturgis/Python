#classe Question
class Question:

    def __init__(self, texte, choix, reponse):
        self.texte = texte
        self.choix = choix
        self.reponse = reponse.lower()

    def verifier_reponse(self, reponse_utilisateur):
        return reponse_utilisateur.lower() == self.reponse