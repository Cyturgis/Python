from qcm import QCM
from questions import Question

def main():
    qcm = QCM()
    #définition des questions, les questions sont ajoutées dans la liste "self.questions" grâce à la fonction "ajouter_question".
    #les paramètres des questions sont entrés grâce à la structure de la classe "Question" --> texte, choix, reponse
    qcm.addQuestion(Question("Quelle est la capital du Brésil ?", ["Bratislava", "Brasilia", "Rio de Janeiro"], "b"))
    qcm.addQuestion(Question("Quelle est la capitale des Etats-Unis ?", ["New York", "Los Angeles", "Washington"], "c"))
    qcm.addQuestion(Question("Quelle est la capitale de la Slovénie ?", ["Tirana", "Nicosie", "Ljubljana"], "c"))
    qcm.addQuestion(Question("Quelle est la capitale du Brunei ?", ["Bandar Seri Begawan", "Harare", "Mbabane"], "a"))
    qcm.addQuestion(Question("Quelle est la capitale de la Nouvelle Zélande ?", ["Auckland", "Camberra", "Wellington"], "c"))
    qcm.addQuestion(Question("Quelle est la capitale du Togo ?", ["Lomé", "Dakar", "Pretoria"], "a"))
    qcm.addQuestion(Question("Quelle est la capitale du Honduras ?", ["Khartoum", "Tegucigalpa", "Belmopan"], "b"))
    qcm.addQuestion(Question("Quelle est la capitale de l'Alaska ?", ["Fairbanks", "Washington", "Anchorage"], "b"))
    qcm.addQuestion(Question("Quelle est la capitale de la République Tchèque ?", ["Prague", "Budapest", "Zagreb"], "a"))
    qcm.addQuestion(Question("Quelle est la capitale du Vatican ?", ["Rome", "Milan", "Vatican"], "c"))

    #fonction qui va choisir une question, la poser et stocker le score du joueur
    qcm.askQuestion()

    #fonction qui affiche le score rempli par la fonction poser_questions()
    qcm.printScore()


if __name__ == "__main__":
    main()

