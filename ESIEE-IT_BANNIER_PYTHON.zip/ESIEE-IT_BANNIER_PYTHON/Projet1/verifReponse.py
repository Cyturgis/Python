import unittest
from questions import Question


#on effectue des tests unitaires grâce à deux fonctions testCorrectResponse et testFalseResponse
#le premier test vérifie que le code fonctionne bien dans le cas où le joueur répond correctement
#le deuxième test vérifie que le code fonctionne bien dans le cas où le joueur répond mal

class Test(unittest.TestCase):
    def testCorrectResponse(self):
        question = Question("testCorrectResponse", ["A", "B", "C"], "a")
        self.assertTrue(question.verifier_reponse("a"))

    def testFalseResponse(self):
        question = Question("testFalseResponse", ["A", "B", "C"], "a")
        self.assertFalse(question.verifier_reponse("b"))

if __name__ == "__main__":
    unittest.main()
